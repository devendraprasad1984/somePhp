# ReactNativeReduxCasts
Companion Repo for [The Complete React Native and Redux Course](https://www.udemy.com/the-complete-react-native-and-redux-course)

This repo is organized by branches - each branch lines up with one video in the course.  You can use the branch seletor (above, to the left side) to select the section you want to see.  Alternatively, you can just look at the completed code, which is available on the master branch.


