## Course Diagrams

All diagrams are authored using https://www.draw.io/


-  You can edit diagrams on your own!
-  Go to https://github.com/StephenGrider/ReduxCodeV2/tree/master/diagrams/
-  Open the folder containing the set of diagrams you want to edit
-  Click on the ‘.xml’ file
-  Click the ‘raw’ button
-  Copy the URL
-  Go to https://www.draw.io/
-  On the ‘Save Diagrams To…’ window click ‘Decide later’ at the bottom
-  Click ‘File’ -> ‘Import From’ -> ‘URL’
-  Paste the link to the XML file
-  Tada!
